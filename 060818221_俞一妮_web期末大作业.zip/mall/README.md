
## How to run

# Install dependencies
\mall\server>node app.js

# Serve with hot reload at localhost:8080
\mall>npm run dev


# Build for production with minification
\mall>npm run build
```

打开dist文件须同时\mall\server>node app.js

