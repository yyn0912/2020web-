var express = require('express');
var app = express();
var debug = require('debug')('my-application'); // debug模块


//跨域配置
app.all('*', function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DELETE,OPTIONS");
    res.header("X-Powered-By",' 3.2.1')
    res.header("Content-Type", "application/json;charset=utf-8");
    next();
});

//底部
app.get('/guideArr', function (req, res) {

    var data = [ ["购物指南", "购物流程", "会员介绍", "生活旅行", "常见问题", "大家电", "联系客服"],
    ["配送方式", "上门自提", "211限时达", "配送服务查询", "收取标准", "海外配送"],
    ["支付方式", "货到付款", "在线支付", "分期付款", "邮局汇款", "公司转账"],
    ["售后服务", "售后政策", "价格保护", "退款说明", "返修/退换货", "取消订单"] ];

    res.json(data);
})

//轮播
app.get("/carouselItems",function (req,res){

    var data = {
        carouselItems: [
            'static/img/nav/1.jpg',
            'static/img/nav/2.jpg',
            'static/img/nav/3.jpg',
            'static/img/nav/4.jpg',
            'static/img/nav/5.jpg'
        ],
        activity: [
            'static/img/nav/nav_showimg1.jpg',
            'static/img/nav/nav_showimg2.jpg'
        ]
    }
    res.json(data);
})

//rose
app.get('/getRoseonly', function (req, res) {

    var data = {
        title: 'Roseonly',
        link: [ '玫瑰珠宝', '表白', '生日', '求婚', '永生玫瑰', '高级定制', '星座专属', '玫瑰居家', '音乐玫瑰' ],
        detail: [
            {
                bigImg: 'static/img/index/rose/item-rose-1.jpg',
                itemFour: [
                    {
                        title: '永生玫瑰',
                        intro: '不会凋谢的玫瑰',
                        img: 'static/img/index/rose/item-rose-2.jpg'
                    },
                    {
                        title: '为爱而生',
                        intro: '专属守护',
                        img: 'static/img/index/rose/item-rose-1-3.jpg'
                    },
                    {
                        title: '蜡烛香氛',
                        intro: '走进爱情玫瑰园',
                        img: 'static/img/index/rose/item-rose-1-4.jpg'
                    },
                    {
                        title: '室内香薰',
                        intro: '庄重时刻的选择',
                        img: 'static/img/index/rose/item-rose-1-5.jpg'
                    }
                ],
                itemContent: [
                    'static/img/index/rose/item-rose-1-6.jpg',
                    'static/img/index/rose/item-rose-1-7.jpg',
                    'static/img/index/rose/item-rose-1-8.jpg'
                ]
            },
            {
                bigImg: 'static/img/index/rose/item-rose-2-1.jpg',
                itemFour: [
                    {
                        title: '毛绒玩偶',
                        intro: '让它替我拥抱你',
                        img: 'static/img/index/rose/item-rose-2-2.jpg'
                    },
                    {
                        title: '蜡烛礼盒',
                        intro: '遇见你的专属味道',
                        img: 'static/img/index/rose/item-rose-2-3.jpg'
                    },
                    {
                        title: '情侣水杯',
                        intro: '蕴藏浪漫仪式感',
                        img: 'static/img/index/rose/item-rose-2-4.jpg'
                    },
                    {
                        title: '花海花盒',
                        intro: '让爱恋成为生活中盛大的庆典',
                        img: 'static/img/index/rose/item-rose-2-5.jpg'
                    }
                ],
                itemContent: [
                    'static/img/index/rose/item-rose-2-6.jpg',
                    'static/img/index/rose/item-rose-2-7.jpg',
                    'static/img/index/rose/item-rose-2-8.jpg'
                ]
            }
        ]
    };

    res.json(data);
})

//爱吃
app.get('/getEat', function (req, res) {

    var data = {
        title: '爱吃',
        link: [ '百威金樽', '三九胃泰', '宫保鸡丁', '土豆炖牛腩', '水煮牛肉', '小香菇烧肉', '百威魄斯', 'ME3果啤', '麻辣嫩牛', '经典鸳鸯', '美式拉格' ],
        detail: [
            {
                bigImg: 'static/img/index/eat/item-eat-1-1.jpg',
                itemFour: [
                    {
                        title: '百威金樽',
                        intro: '尊遇之享',
                        img: 'static/img/index/eat/item-eat-1-2.jpg'
                    },
                    {
                        title: '百威冰啤',
                        intro: '圆润顺滑',
                        img: 'static/img/index/eat/item-eat-1-3.jpg'
                    },
                    {
                        title: 'ME3果啤',
                        intro: '果汁拉格，迷之口感',
                        img: 'static/img/index/eat/item-eat-1-4.jpg'
                    },
                    {
                        title: '百威纯生',
                        intro: '真我至上',
                        img: 'static/img/index/eat/item-eat-1-5.jpg'
                    }
                ],
                itemContent: [
                    'static/img/index/eat/item-eat-1-6.jpg',
                    'static/img/index/eat/item-eat-1-7.jpg',
                    'static/img/index/eat/item-eat-1-8.jpg'
                ]
            },
            {
                bigImg: 'static/img/index/eat/item-eat-2-1.jpg',
                itemFour: [
                    {
                        title: '开小灶',
                        intro: '自热米饭',
                        img: 'static/img/index/eat/item-eat-2-2.jpg'
                    },
                    {
                        title: '开小灶',
                        intro: '自热米饭',
                        img: 'static/img/index/eat/item-eat-2-2.jpg'
                    },
                    {
                        title: '开小灶',
                        intro: '自热米饭',
                        img: 'static/img/index/eat/item-eat-2-2.jpg'
                    },
                    {
                        title: '开小灶',
                        intro: '自热米饭',
                        img: 'static/img/index/eat/item-eat-2-2.jpg'
                    }
                ],
                itemContent: [
                    'static/img/index/eat/item-eat-2-6.jpg',
                    'static/img/index/eat/item-eat-2-7.jpg',
                    'static/img/index/eat/item-eat-2-8.jpg'
                ]
            }
        ]
    };

    res.json(data);
})


app.get('/getGoodsList',function (req,res){
    var data =  {
        asItems: [
            {
                img: 'static/img/goodsList/item-as-img-1.jpg',
                price: 199,
                intro: 'Budweiser/百威Pulse魄斯啤酒定制268ml*12',
                num: 3140,
                sale: 9000
            },
            {
                img: 'static/img/goodsList/item-as-img-2.jpg',
                price: 69999,
                intro: 'ROSEONLY高端定制 永生玫瑰花公仔 七彩玫瑰兔60cm',
                num: 6160,
                sale: 8900
            },
            {
                img: 'static/img/goodsList/item-as-img-1.jpg',
                price: 199,
                intro: 'Budweiser/百威Pulse魄斯啤酒定制268ml*12',
                num: 3140,
                sale: 9000
            },
            {
                img: 'static/img/goodsList/item-as-img-2.jpg',
                price: 69999,
                intro: 'ROSEONLY高端定制 永生玫瑰花公仔 七彩玫瑰兔60cm',
                num: 6160,
                sale: 8900
            },
            {
                img: 'static/img/goodsList/item-as-img-1.jpg',
                price: 199,
                intro: 'Budweiser/百威Pulse魄斯啤酒定制268ml*12',
                num: 3140,
                sale: 9000
            },
            {
                img: 'static/img/goodsList/item-as-img-2.jpg',
                price: 69999,
                intro: 'ROSEONLY高端定制 永生玫瑰花公仔 七彩玫瑰兔60cm',
                num: 6160,
                sale: 8900
            }
        ],
        
        goodsList:[
            {
                gid:0,
                img: 'static/img/goodsList/item-show-1.jpg',
                price: 69999.00,
                intro: 'ROSEONLY高端定制 永生玫瑰花公仔 七彩玫瑰兔60cm',
                remarks: 6160,
                shopName: '自营',
                sale: 9900
            },
            {
                gid:1,
                img: 'static/img/goodsList/item-show-2.jpg',
                price: 99.00,
                intro: '统一开小灶自热料理方便米饭三鲜烩四喜整箱4盒',
                remarks: 3000,
                shopName: '自营',
                sale: 9600
            },
            {
                gid:2,
                img: 'static/img/goodsList/item-show-3.jpg',
                price: 99.00,
                intro: '统一开小灶自热料理方便米饭水煮牛肉整箱装4盒',
                remarks: 2800,
                shopName: '自营',
                sale: 8900
            },
            {
                gid:3,
                img: 'static/img/goodsList/item-show-4.jpg',
                price: 1314.00,
                intro: 'ROSEONLY永生玫瑰 12星座水滴形永生玫瑰花礼盒',
                remarks: 9000,
                shopName: '自营',
                sale: 8600
            },
            {
                gid: 4,
                img: 'static/img/goodsList/item-show-5.jpg',
                price: 99.00,
                intro: '统一开小灶自热料理方便米饭广式腊味煲仔饭整箱装4盒',
                remarks: 6160,
                shopName: '自营',
                sale: 8560
            },
            {
                gid: 5,
                img: 'static/img/goodsList/item-show-6.jpg',
                price: 99.00,
                intro: '统一开小灶自热料理方便米饭小香菇烧肉风味整箱装4盒',
                remarks: 9006,
                shopName: '自营',
                sale: 8530
            },
            {
                gid: 6,
                img: 'static/img/goodsList/item-show-7.jpg',
                price: 99.00,
                intro: '统一开小灶自热料理方便米饭土豆煨牛腩整箱装4盒',
                remarks: 8666,
                shopName: '自营',
                sale: 8360
            },
            {
                gid: 7,
                img: 'static/img/goodsList/item-show-8.jpg',
                price: 99.00,
                intro: '统一开小灶自热料理方便米饭宫保鸡丁风味整箱装4盒',
                remarks: 6080,
                shopName: '自营',
                sale: 7560
            },
            {
                gid:8,
                img: 'static/img/goodsList/item-show-9.jpg',
                price: 109.00,
                intro: 'Budweiser/百威啤酒天猫精灵糖衣联名款',
                remarks: 6160,
                shopName: '自营',
                sale: 7360
            },
            {
                gid: 9,
                img: 'static/img/goodsList/item-show-10.jpg',
                price: 218.00,
                intro: 'Budweiser/百威啤酒精酿大师臻藏798ml*1大瓶装',
                remarks: 3000,
                shopName: '自营',
                sale: 6960
            },
            {
                gid:10,
                img: 'static/img/goodsList/item-show-11.jpg',
                price: 69.00,
                intro: 'Budweiser/百威限量定制百威亲吻瓶355ml*4瓶礼盒装',
                remarks: 2800,
                shopName: '自营',
                sale: 6560
            },
            {
                gid: 12,
                img: 'static/img/goodsList/item-show-12.jpg',
                price: 199.00,
                intro: 'Budweiser/百威Pulse魄斯啤酒定制268ml*12瓶',
                remarks: 9000,
                shopName: '自营',
                sale: 6360
            },
            {
                gid: 12,
                img: 'static/img/goodsList/item-show-13.jpg',
                price: 169.00,
                intro: 'Budweiser/百威啤酒金尊啤酒500ml*12大瓶装',
                remarks: 6160,
                shopName: '自营',
                sale: 5530
            },
            {
                gid: 13,
                img: 'static/img/goodsList/item-show-14.jpg',
                price: 298.00,
                intro: 'Budweiser/百威果啤270ml*10听+百威魄斯268ml*12瓶组合装',
                remarks: 9006,
                shopName: '自营',
                sale: 5560
            },
            {
                gid: 14,
                img: 'static/img/goodsList/item-show-15.jpg',
                price: 139.00,
                intro: 'Budweiser/百威啤酒纯生330ml*24听小罐装',
                remarks: 8666,
                shopName: '自营',
                sale: 5260
            },
            {
                gid: 15,
                img: 'static/img/goodsList/item-show-16.jpg',
                price: 119.00,
                intro: 'Budweiser/百威啤酒ME3果啤真的很迷270ml*10听',
                remarks: 6080,
                shopName: '自营',
                sale: 3560
            },
            {
                gid: 16,
                img: 'static/img/goodsList/item-show-17.jpg',
                price: 139.00,
                intro: 'Budweiser/百威啤酒经典醇正330ml*24小罐装',
                remarks: 6080,
                shopName: '自营',
                sale: 3560
            },
            {
                gid: 17,
                img: 'static/img/goodsList/item-show-18.jpg',
                price: 89.00,
                intro: 'Budweiser/百威啤酒瓶装美式拉格600ml*12大瓶',
                remarks: 6080,
                shopName: '自营',
                sale: 3560
            },
            {
                gid: 18,
                img: 'static/img/goodsList/item-show-19.jpg',
                price: 119.00,
                intro: 'Budweiser/百威啤酒整箱经典醇正550ml*15大罐',
                remarks: 6080,
                shopName: '自营',
                sale: 3560
            },
            {
                gid: 19,
                img: 'static/img/goodsList/item-show-20.jpg',
                price: 1314.00,
                intro: 'ROSEONLY玫瑰星球水球礼盒 萌兔水晶球摆件',
                remarks: 6080,
                shopName: '自营',
                sale: 3560
            }]
    };

    res.json(data);
})

app.get("/getPanelData1",function (req,res){

    const data = {
        navTags: [ '清洁用品', '美妆商城', '美妆馆', '妆比社', '全球购美妆', '宠物馆' ],
        classNav: [
            {
                title: '面部护肤',
                tags: [ '补水保湿', '卸妆', '洁面', '爽肤水', '乳液面霜', '精华', '眼霜', '防晒', '面膜', '剃须', '套装' ]
            },
            {
                title: '洗发护发',
                tags: [ '洗发', '护发', '染发', '造型', '假发', '美发工具', '套装' ]
            },
            {
                title: '身体护理',
                tags: [ '补水保湿', '沐浴', '润肤', '精油', '颈部', '手足', '纤体塑形', '美胸', '套装' ]
            },
            {
                title: '口腔护理',
                tags: [ '牙膏/牙粉', '牙刷/牙线', '漱口水', '套装' ]
            },
            {
                title: '女性护理',
                tags: [ '卫生巾', '卫生护垫', '私密护理', '脱毛膏' ]
            },
            {
                title: '香水彩妆',
                tags: [ 'BB霜', '化妆棉', '女士香水', '男士香水', '底妆', '眉笔', '睫毛膏', '眼线', '眼影', '唇膏/彩' ]
            },
            {
                title: '清洁用品',
                tags: [ '纸品湿巾', '衣物清洁', '清洁工具', '家庭清洁', '一次性用品', '驱虫用品', '皮具护理' ]
            },
            {
                title: '宠物生活',
                tags: [ '水族世界', '狗粮', '猫粮', '猫狗罐头', '狗零食', '猫零食', '医疗保健', '宠物玩具', '宠物服饰' ]
            },
            {
                title: '香水彩妆',
                tags: [ 'BB霜', '化妆棉', '女士香水', '男士香水', '底妆', '眉笔', '睫毛膏', '眼线', '眼影', '唇膏/彩' ]
            },
            {
                title: '清洁用品',
                tags: [ '纸品湿巾', '衣物清洁', '清洁工具', '家庭清洁', '一次性用品', '驱虫用品', '皮具护理' ]
            },
            {
                title: '宠物生活',
                tags: [ '水族世界', '狗粮', '猫粮', '猫狗罐头', '狗零食', '猫零食', '医疗保健', '宠物玩具', '宠物服饰' ]
            }
        ]
    };

    res.json(data);

})

app.get("/getPanelData2",function (req,res){

    const data = {
        navTags: [ '赛事', '运动城', '户外馆', '健身房', '骑行馆', '钟表城' ],
        classNav: [
            {
                title: '2020新品',
                tags: [ '休闲鞋', '商务休闲鞋', '正装鞋', '帆布鞋', '凉鞋', '拖鞋', '功能鞋', '增高鞋', '工装鞋', '雨鞋' ]
            },
            {
                title: '运动鞋包',
                tags: [ '跑步鞋', '休闲鞋', '篮球鞋', '帆布鞋', '板鞋', '拖鞋', '运动包' ]
            },
            {
                title: '健身训练',
                tags: [ '跑步机', '健身车/动感单车', '椭圆机', '综合训练器', '划船机', '甩脂机', '倒立机', '武术搏击' ]
            },
            {
                title: '骑行运动',
                tags: [ '山地车', '公路车', '折叠车', '骑行服', '电动车', '电动滑板车', '城市自行车', '平衡车' ]
            },
            {
                title: '体育用品',
                tags: [ '乒乓球', '羽毛球', '篮球', '足球', '轮滑滑板', '网球', '高尔夫', '台球', '排球' ]
            },
            {
                title: '户外鞋服',
                tags: [ '户外风衣', '徒步鞋', 'T恤', '冲锋衣裤', '速干衣裤', '越野跑鞋', '滑雪服', '羽绒服/棉服', '休闲衣裤' ]
            },
            {
                title: '户外装备',
                tags: [ '背包', '帐篷/垫子', '望远镜', '烧烤用具', '便携桌椅床', '户外配饰', '军迷用品', '野餐用品' ]
            },
            {
                title: '垂钓用品',
                tags: [ '钓竿', '鱼线', '浮漂', '鱼饵', '钓鱼配件', '渔具包', '钓箱钓椅', '鱼线轮', '钓鱼灯' ]
            },
            {
                title: '游泳用品',
                tags: [ '女士泳衣', '比基尼', '男士泳衣', '泳镜', '游泳圈', '游泳包防水包', '泳帽', '游泳配件' ]
            },
            {
                title: '垂钓用品',
                tags: [ '钓竿', '鱼线', '浮漂', '鱼饵', '钓鱼配件', '渔具包', '钓箱钓椅', '鱼线轮', '钓鱼灯' ]
            },
            {
                title: '游泳用品',
                tags: [ '女士泳衣', '比基尼', '男士泳衣', '泳镜', '游泳圈', '游泳包防水包', '泳帽', '游泳配件' ]
            }
        ]
    };

    res.json(data);

})

app.get("/getTagsInfo",function (req,res){
    const data =  [
        {
            tagName: '品牌',
            tags: [ '统一开小灶', '良品铺子', 'Roseonly', '小鹿茶', '蒙牛真果粒', '百威',  '其他' ]
        },
        {
            tagName: '分类',
            tags: [ '自热米饭', '自热火锅', '奶茶', '啤酒', '红酒', '玫瑰花', '居家' ]
        },
        {
            tagName: '口味',
            tags: [ '酸', '甜', '苦', '辣', '咸', '其他' ]
        },
        {
            tagName: '价格',
            tags: [ '0-99', '100-199', '200-299', '300-399', '400-499', '500-1000', '1000-2000', '2000-3000', '3000-30000' ]
        }
    ];
    res.json(data);
})

app.get("/getShopIntro",function (req,res){
    const data = {
        shopName: '自营店',
        slogen: '给客户最好的选择',
        showGoods: []
    }
    res.json(data);
})


app.get("/getGoodsInfo",function (req,res){

    const param= [
        {
            title: '商品名称',
            content: '商品'
        },
        {
            title: '商品编号',
            content: '10435663237'
        },
        {
            title: '店铺',
            content: '自营'
        },
        {
            title: '商品数量',
            content: '1件'
        },
        {
            title: '商品产地',
            content: '中国大陆'
        },
        {
            title: '适用人群',
            content: '通用'
        }
    ];
    const remarks={
        goodAnalyse: 90,
            remarksTags: [ '好吃', '实惠优选', '好喝', '性价比高', '质量没话说', '比定做还合适', '完美品质', '正品行货', '包装有档次', '上档次', '已经买第二个', '强烈推荐' ],
            remarksNumDetail: [ 2000, 3000, 900, 1 ],
            detail: [
            {
                username: 'p****1',
                values: 3,
                content: '好！',
                goods: '商品',
                create_at: '2020-05-15 09:20'
            },
            {
                username: '13****1',
                values: 5,
                content: '很满意。物流很快。很愉快的一次购物！',
                goods: '商品',
                create_at: '2020-05-13 15:23'
            },
            {
                username: '3****z',
                values: 4.5,
                content: '店家还送了很多，非常值得！',
                goods: '商品',
                create_at: '2020-05-05 12:25'
            },
            {
                username: 'gd****c',
                values: 3.5,
                content: '就是我想要赶快下手了。',
                goods: '商品',
                create_at: '2020-04-06 16:23'
            },
            {
                username: 'r****b',
                values: 4.5,
                content: '很不错我很满意',
                goods: '商品',
                create_at: '2020-03-15 19:24'
            },
            {
                username: 'd****e',
                values: 5,
                content: '好评！',
                goods: '商品',
                create_at: '2020-03-10 10:13'
            }
        ]};


    let params = String(parseInt(req.query['gid'])+1);

    if(params==null){
        params = '1';
    }

    var names=[
        'ROSEONLY高端定制 永生玫瑰花公仔 七彩玫瑰兔60cm',
        '统一开小灶自热料理方便米饭三鲜烩四喜整箱4盒',
        '统一开小灶自热料理方便米饭水煮牛肉整箱装4盒',
        'ROSEONLY永生玫瑰 12星座水滴形永生玫瑰花礼盒',
        '统一开小灶自热料理方便米饭广式腊味煲仔饭整箱装4盒',
        '统一开小灶自热料理方便米饭小香菇烧肉风味整箱装4盒',
        '统一开小灶自热料理方便米饭土豆煨牛腩整箱装4盒',
        '统一开小灶自热料理方便米饭宫保鸡丁风味整箱装4盒',
        'Budweiser/百威啤酒天猫精灵糖衣联名款',
        'Budweiser/百威啤酒精酿大师臻藏798ml*1大瓶装',
        'Budweiser/百威限量定制百威亲吻瓶355ml*4瓶礼盒装',
        'Budweiser/百威Pulse魄斯啤酒定制268ml*12瓶',
        'Budweiser/百威啤酒金尊啤酒500ml*12大瓶装',
        'Budweiser/百威果啤270ml*10听+百威魄斯268ml*12瓶组合装',
        'Budweiser/百威啤酒纯生330ml*24听小罐装',
        'Budweiser/百威啤酒ME3果啤真的很迷270ml*10听',
        'Budweiser/百威啤酒经典醇正330ml*24小罐装',
        'Budweiser/百威啤酒瓶装美式拉格600ml*12大瓶',
        'Budweiser/百威啤酒整箱经典醇正550ml*15大罐',
        'ROSEONLY玫瑰星球水球礼盒 萌兔水晶球摆件',]


    const data = {
        goodsImg: [
            'static/img/goodsDetail/'+params+'/1.jpg',
            'static/img/goodsDetail/'+params+'/2.jpg',
            'static/img/goodsDetail/'+params+'/3.jpg',
            'static/img/goodsDetail/'+params+'/4.jpg'
        ],
        title: names[req.query['gid']],
        tags: ['满69-20元', '关注产品送精美礼品', '配次日达'],
        discount: ['满148减10', '满218减20', '满288减30'],
        promotion: ['跨店满减', '多买优惠'],
        remarksNum: 6000,
        setMeal: [
            [
                {
                    img: 'static/img/goodsDetail/'+params+'/1.jpg',
                    intro: '标签',
                    price: 59.0
                },
                {
                    img: 'static/img/goodsDetail/'+params+'/1.jpg',
                    intro: '标签',
                    price: 1566.0
                },
                {
                    img: 'static/img/goodsDetail/'+params+'/2.jpg',
                    intro: '标签',
                    price: 133.5
                }
            ],
            [
                {
                    img: 'static/img/goodsDetail/'+params+'/3.jpg',
                    intro: '标签',
                    price: 6299.0
                },
                {
                    img: 'static/img/goodsDetail/'+params+'/3.jpg',
                    intro: '标签',
                    price: 32.0
                },
                {
                    img: 'static/img/goodsDetail/'+params+'/4.jpg',
                    intro: '标签',
                    price: 35.0
                }
            ]
        ],
        goodsDetail: [
            'static/img/goodsDetail/intro/1.jpg',
            'static/img/goodsDetail/intro/2.jpg',
            'static/img/goodsDetail/intro/3.jpg',
            'static/img/goodsDetail/intro/4.jpg'
        ],
        param: param,
        remarks: remarks
    };
    res.json(data);
})

app.get("/test",function (req,res){
    var params = req.query['gid'];
    console.log(params==null);
    res.json(params);
})

var server = app.listen(8080, function () {

    console.log("服务启动在端口：8080");
    debug('Express server listening on port ' +8080);

})
